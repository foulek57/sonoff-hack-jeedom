#!/bin/ash
#
# Command line:
# 	ash "/home/yi-hack/script/ftppush.sh" cron
# 	ash "/home/yi-hack/script/ftppush.sh" start
# 	ash "/home/yi-hack/script/ftppush.sh" stop
#
CONF_FILE="etc/mqtt-sonoff.conf"

SONOFF_HACK_PREFIX="/mnt/mmc/sonoff-hack"

get_config()
{
    key=$1
    grep -w $1 $SONOFF_HACK_PREFIX/$CONF_FILE | cut -d "=" -f2
}
# Setup env.
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/mnt/mmc/sonoff-hack/lib
export PATH=$PATH:/mnt/mmc/sonoff-hack/bin:/mnt/mmc/sonoff-hack/sbin:/mnt/mmc/sonoff-hack/usr/bin:/mnt/mmc/sonoff-hack/usr/sbin
#
# Script Configuration.
FOLDER_TO_WATCH="/mnt/mmc/alarm_record"
SLEEP_CYCLE_SECONDS="5"
JEE_IP=$(get_config MQTT_IP)
JEE_PORT=$(get_config MQTT_PORT)
JEE_APIKEY=$(get_config MQTT_CLIENT_ID)
JEE_CMD_ID=$(get_config MQTT_KEEPALIVE)
FOLDER_MINDEPTH="1"
FILE_DELETE_AFTER_UPLOAD="1"
FILE_WATCH_PATTERN="*.mp4"
SKIP_UPLOAD_TO_FTP="0"
#
# Runtime Variables.
SCRIPT_FULLFN="ftppush.sh"
SCRIPT_NAME="ftppush"
LOGFILE="/tmp/${SCRIPT_NAME}.log"
LOG_MAX_LINES="200"
#
# -----------------------------------------------------
# -------------- START OF FUNCTION BLOCK --------------
# -----------------------------------------------------

http_get ()
{
	#
	# Search for new files.
	if [ -f "/usr/bin/sort" ]; then
		# Default: Optimized for busybox
		L_FILE_LIST="$(find "${FOLDER_TO_WATCH}" -mindepth ${FOLDER_MINDEPTH} -type f \( -name "${FILE_WATCH_PATTERN}" \) | sort -k 1 -n)"
	else
		# Alternative: Unsorted output
		L_FILE_LIST="$(find "${FOLDER_TO_WATCH}" -mindepth ${FOLDER_MINDEPTH} -type f \( -name "${FILE_WATCH_PATTERN}" \))"
	fi
	if [ -z "${L_FILE_LIST}" ]; then
		return 0
	fi
	#
	echo "${L_FILE_LIST}" | while read file; do
		if [ "${FILE_DELETE_AFTER_UPLOAD}" = "1" ]; then
			rm -f "${file}"
		fi
		#
	done
	#
	# Delete empty sub directories
	wget -s ${JEE_IP}":"${JEE_PORT}"/core/api/jeeApi.php?apikey="${JEE_APIKEY}"&type=cmd&id="${JEE_CMD_ID}"&title=montitre&message=Alerte_cam_Sonoff"
	if [ ! -z "${FOLDER_TO_WATCH}" ]; then
		find "${FOLDER_TO_WATCH}/" -mindepth 1 -type d -empty -delete
	fi
	#
	return 0
}
lstat ()
{
	if [ -d "${1}" ]; then
		ls -a -l -td "${1}" | awk '{k=0;for(i=0;i<=8;i++)k+=((substr($1,i+2,1)~/[rwx]/) \
				 *2^(8-i));if(k)printf("%0o ",k);print}' | \
				 cut -d " " -f 1
	else
		ls -a -l "${1}" | awk '{k=0;for(i=0;i<=8;i++)k+=((substr($1,i+2,1)~/[rwx]/) \
				 *2^(8-i));if(k)printf("%0o ",k);print}' | \
				 cut -d " " -f 1
	fi
}
serviceMain ()
{
	#
	# Usage:		serviceMain	[--one-shot]
	# Called By:	MAIN
	#
	echo "[INFO] === SERVICE START ==="
	# sleep 10
	while (true); do
		# Check if folder exists.
		if [ ! -d "${FOLDER_TO_WATCH}" ]; then 
			mkdir -p "${FOLDER_TO_WATCH}"
		fi
		# 
		# Ensure correct file permissions.
		if ( ! lstat "${FOLDER_TO_WATCH}/" | grep -q "^755$" ); then
			echo "[WARN] Adjusting folder permissions to 0755 ..."
			chmod -R 0755 "${FOLDER_TO_WATCH}"
		fi
		#
		echo $JEE_IP
		echo $JEE_PORT
		echo $JEE_APIKEY
		echo $JEE_CMD_ID

		http_get
		sleep ${SLEEP_CYCLE_SECONDS}
	done
	return 0
}
# ---------------------------------------------------
# -------------- END OF FUNCTION BLOCK --------------
# ---------------------------------------------------
#
# set +m
trap "" SIGHUP
#
if [ "${1}" = "cron" ]; then
	serviceMain --one-shot
	echo "[INFO] === SERVICE STOPPED ==="
	exit 0
elif [ "${1}" = "start" ]; then
	serviceMain &
	#
	# Wait for kill -INT.
	wait
	exit 0
elif [ "${1}" = "stop" ]; then
	ps w | grep -v grep | grep "ash ${0}" | sed 's/ \+/|/g' | sed 's/^|//' | cut -d '|' -f 1 | grep -v "^$$" | while read pidhandle; do
		echo "[INFO] Terminating old service instance [${pidhandle}] ..."
		kill -9 "${pidhandle}"
	done
	#
	# Check if parts of the service are still running.
	if [ "$(ps w | grep -v grep | grep "ash ${0}" | sed 's/ \+/|/g' | sed 's/^|//' | cut -d '|' -f 1 | grep -v "^$$" | grep -c "^")" -gt 1 ]; then
		echo "[ERROR] === SERVICE FAILED TO STOP ==="
		exit 99
	fi
	echo "[INFO] === SERVICE STOPPED ==="
	exit 0
fi
#
echo "[ERROR] Parameter #1 missing."
echo "[INFO] Usage: ${SCRIPT_FULLFN} {cron|start|stop}"
exit 99
