#!/bin/sh

echo "############## Starting Hack ##############"

(sleep 30 && /mnt/mmc/sonoff-hack/script/system.sh) &
